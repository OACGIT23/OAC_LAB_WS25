prompt --application/pages/page_00003
begin
--   Manifest
--     PAGE: 00003
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.6'
,p_default_workspace_id=>7834776098045050
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'WKSP_OACLABWS'
);
wwv_flow_imp_page.create_page(
 p_id=>3
,p_name=>'Submit Expense'
,p_alias=>'SUBMIT-EXPENSE'
,p_step_title=>'Submit Expense'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'17'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(8776599154426930)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2531463326621247859
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(8648010860604494)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8778097316422008)
,p_button_sequence=>60
,p_button_name=>'SUBMIT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Submit'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8754229475822749)
,p_name=>'P3_EMP_NAME'
,p_item_sequence=>20
,p_prompt=>'Employee Name'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8754302838822750)
,p_name=>'P3_EXPENSE_AMOUNT'
,p_item_sequence=>40
,p_prompt=>'Expense Amount'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8777387261422001)
,p_name=>'P3_EXPENSE_REASON'
,p_item_sequence=>50
,p_prompt=>'Expense Reason'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8777459674422002)
,p_name=>'P3_EMP_MAIL'
,p_item_sequence=>30
,p_prompt=>'Employee Email'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(8777541819422003)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_WORKFLOW'
,p_process_name=>'Submit Expense'
,p_attribute_01=>'START'
,p_attribute_02=>wwv_flow_imp.id(8221790293067345)
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(8778097316422008)
,p_process_success_message=>'Expense Report Submitted!'
,p_internal_uid=>8777541819422003
);
wwv_flow_imp_shared.create_workflow_comp_param(
 p_id=>wwv_flow_imp.id(8777676474422004)
,p_page_process_id=>wwv_flow_imp.id(8777541819422003)
,p_workflow_variable_id=>wwv_flow_imp.id(8749607966822703)
,p_page_id=>3
,p_value_type=>'ITEM'
,p_value=>'P3_EXPENSE_AMOUNT'
);
wwv_flow_imp_shared.create_workflow_comp_param(
 p_id=>wwv_flow_imp.id(8777709562422005)
,p_page_process_id=>wwv_flow_imp.id(8777541819422003)
,p_workflow_variable_id=>wwv_flow_imp.id(8749599110822702)
,p_page_id=>3
,p_value_type=>'ITEM'
,p_value=>'P3_EXPENSE_REASON'
);
wwv_flow_imp_shared.create_workflow_comp_param(
 p_id=>wwv_flow_imp.id(8777843097422006)
,p_page_process_id=>wwv_flow_imp.id(8777541819422003)
,p_workflow_variable_id=>wwv_flow_imp.id(8749848557822705)
,p_page_id=>3
,p_value_type=>'ITEM'
,p_value=>'P3_EMP_MAIL'
);
wwv_flow_imp_shared.create_workflow_comp_param(
 p_id=>wwv_flow_imp.id(8777995588422007)
,p_page_process_id=>wwv_flow_imp.id(8777541819422003)
,p_workflow_variable_id=>wwv_flow_imp.id(8749736791822704)
,p_page_id=>3
,p_value_type=>'ITEM'
,p_value=>'P3_EMP_NAME'
);
wwv_flow_imp.component_end;
end;
/
