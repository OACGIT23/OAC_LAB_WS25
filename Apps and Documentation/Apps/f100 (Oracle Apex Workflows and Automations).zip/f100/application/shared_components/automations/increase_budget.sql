prompt --application/shared_components/automations/increase_budget
begin
--   Manifest
--     AUTOMATION: Increase Budget
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.6'
,p_default_workspace_id=>7834776098045050
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'WKSP_OACLABWS'
);
wwv_flow_imp_shared.create_automation(
 p_id=>wwv_flow_imp.id(8897989320954509)
,p_name=>'Increase Budget'
,p_static_id=>'increase-budget'
,p_trigger_type=>'POLLING'
,p_polling_interval=>'FREQ=HOURLY;INTERVAL=2;BYMINUTE=0'
,p_polling_status=>'ACTIVE'
,p_result_type=>'ROWS'
,p_location=>'LOCAL'
,p_use_local_sync_table=>false
,p_query_type=>'TABLE'
,p_query_table=>'EBA_PROJECTS'
,p_include_rowid_column=>false
,p_commit_each_row=>false
,p_error_handling_type=>'IGNORE'
);
wwv_flow_imp_shared.create_automation_action(
 p_id=>wwv_flow_imp.id(8898295546954480)
,p_automation_id=>wwv_flow_imp.id(8897989320954509)
,p_name=>'Increase BUDGET for Project'
,p_execution_sequence=>10
,p_action_type=>'NATIVE_PLSQL'
,p_action_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    update EBA_PROJECTS set BUDGET = round(BUDGET * 2, 1) where ID = :ID;',
'    apex_automation.log_info(''Budget for '' || :NAME || '' increased.'');',
'end;'))
,p_action_clob_language=>'PLSQL'
,p_location=>'LOCAL'
,p_stop_execution_on_error=>true
,p_condition_type=>'EXPRESSION'
,p_condition_expr1=>':NAME = ''Configure Web Environment'''
,p_condition_expr2=>'PLSQL'
,p_exec_cond_for_each_row=>true
);
wwv_flow_imp.component_end;
end;
/
