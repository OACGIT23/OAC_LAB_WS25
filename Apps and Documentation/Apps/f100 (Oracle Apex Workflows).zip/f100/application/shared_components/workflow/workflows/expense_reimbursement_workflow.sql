prompt --application/shared_components/workflow/workflows/expense_reimbursement_workflow
begin
--   Manifest
--     WORKFLOW: Expense Reimbursement Workflow
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.6'
,p_default_workspace_id=>7834776098045050
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'WKSP_OACLABWS'
);
wwv_flow_imp_shared.create_workflow(
 p_id=>wwv_flow_imp.id(8221790293067345)
,p_name=>'Expense Reimbursement Workflow'
,p_static_id=>'EXP_REIMBURSEMENT_WF '
,p_title=>'Expense Reimbursement for &EMP_NAME.'
);
wwv_flow_imp_shared.create_workflow_variable(
 p_id=>wwv_flow_imp.id(8749599110822702)
,p_workflow_id=>wwv_flow_imp.id(8221790293067345)
,p_label=>'DESC'
,p_static_id=>'DESC'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_is_required=>true
);
wwv_flow_imp_shared.create_workflow_variable(
 p_id=>wwv_flow_imp.id(8749607966822703)
,p_workflow_id=>wwv_flow_imp.id(8221790293067345)
,p_label=>'AMOUNT'
,p_static_id=>'AMOUNT'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_is_required=>false
);
wwv_flow_imp_shared.create_workflow_variable(
 p_id=>wwv_flow_imp.id(8749736791822704)
,p_workflow_id=>wwv_flow_imp.id(8221790293067345)
,p_label=>'EMP_NAME'
,p_static_id=>'EMP_NAME'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_is_required=>true
);
wwv_flow_imp_shared.create_workflow_variable(
 p_id=>wwv_flow_imp.id(8749848557822705)
,p_workflow_id=>wwv_flow_imp.id(8221790293067345)
,p_label=>'EMP_EMAIL'
,p_static_id=>'EMP_EMAIL'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_is_required=>true
);
wwv_flow_imp_shared.create_workflow_version(
 p_id=>wwv_flow_imp.id(8221890312067346)
,p_workflow_id=>wwv_flow_imp.id(8221790293067345)
,p_version=>'1.0'
,p_state=>'DEVELOPMENT'
);
wwv_flow_imp_shared.create_workflow_variable(
 p_id=>wwv_flow_imp.id(8749921716822706)
,p_workflow_version_id=>wwv_flow_imp.id(8221890312067346)
,p_label=>'Max Level'
,p_static_id=>'MAX_LEVEL'
,p_direction=>'VARIABLE'
,p_data_type=>'NUMBER'
,p_value_type=>'NULL'
);
wwv_flow_imp_shared.create_workflow_variable(
 p_id=>wwv_flow_imp.id(8750098456822707)
,p_workflow_version_id=>wwv_flow_imp.id(8221890312067346)
,p_label=>'Current Level'
,p_static_id=>'CURRENT_LEVEL'
,p_direction=>'VARIABLE'
,p_data_type=>'NUMBER'
,p_value_type=>'STATIC'
,p_value=>'1'
);
wwv_flow_imp_shared.create_workflow_variable(
 p_id=>wwv_flow_imp.id(8750434963822711)
,p_workflow_version_id=>wwv_flow_imp.id(8221890312067346)
,p_label=>'Approver'
,p_static_id=>'APPROVER'
,p_direction=>'VARIABLE'
,p_data_type=>'VARCHAR2'
,p_value_type=>'NULL'
);
wwv_flow_imp_shared.create_workflow_variable(
 p_id=>wwv_flow_imp.id(8750563708822712)
,p_workflow_version_id=>wwv_flow_imp.id(8221890312067346)
,p_label=>'TaskOutcome'
,p_static_id=>'TASK_OUTCOME'
,p_direction=>'VARIABLE'
,p_data_type=>'VARCHAR2'
,p_value_type=>'NULL'
);
wwv_flow_imp_shared.create_workflow_activity(
 p_id=>wwv_flow_imp.id(8221923143067347)
,p_workflow_version_id=>wwv_flow_imp.id(8221890312067346)
,p_name=>'Start'
,p_static_id=>'New'
,p_display_sequence=>10
,p_activity_type=>'NATIVE_WORKFLOW_START'
,p_diagram=>'{"position":{"x":150,"y":940},"z":1}'
);
wwv_flow_imp_shared.create_workflow_activity(
 p_id=>wwv_flow_imp.id(8222106428067349)
,p_workflow_version_id=>wwv_flow_imp.id(8221890312067346)
,p_name=>'End'
,p_static_id=>'New_2'
,p_display_sequence=>30
,p_activity_type=>'NATIVE_WORKFLOW_END'
,p_attribute_01=>'COMPLETED'
,p_diagram=>'{"position":{"x":150,"y":1920},"z":3}'
);
wwv_flow_imp_shared.create_workflow_activity(
 p_id=>wwv_flow_imp.id(8750136408822708)
,p_workflow_version_id=>wwv_flow_imp.id(8221890312067346)
,p_name=>'Compute Max Level'
,p_static_id=>'New_1'
,p_display_sequence=>40
,p_activity_type=>'NATIVE_PLSQL'
,p_activity_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    level_no number;',
'begin',
'    if :AMOUNT < 500 then',
'        level_no := -1;',
'    elsif :AMOUNT < 1000 then',
'        level_no := 1;',
'    elsif :AMOUNT < 5000 then',
'        level_no := 2;',
'    else',
'        level_no := 3;',
'    end if;',
'    :MAX_LEVEL := level_no;',
'end;'))
,p_activity_code_language=>'PLSQL'
,p_location=>'LOCAL'
,p_diagram=>'{"position":{"x":70,"y":1070},"z":5}'
);
wwv_flow_imp_shared.create_workflow_activity(
 p_id=>wwv_flow_imp.id(8750229146822709)
,p_workflow_version_id=>wwv_flow_imp.id(8221890312067346)
,p_name=>'Approval Needed?'
,p_static_id=>'New_3'
,p_display_sequence=>50
,p_activity_type=>'NATIVE_WORKFLOW_SWITCH'
,p_attribute_01=>'TRUE_FALSE_CHECK'
,p_attribute_03=>'WF_VARIABLE_EQ_VAL'
,p_attribute_08=>'MAX_LEVEL'
,p_attribute_14=>'-1'
,p_diagram=>'{"position":{"x":70,"y":1200},"z":6}'
);
wwv_flow_imp_shared.create_workflow_activity(
 p_id=>wwv_flow_imp.id(8750301394822710)
,p_workflow_version_id=>wwv_flow_imp.id(8221890312067346)
,p_name=>'Create Approval Request'
,p_static_id=>'New_4'
,p_display_sequence=>60
,p_activity_type=>'NATIVE_CREATE_TASK'
,p_attribute_01=>wwv_flow_imp.id(8668995089568463)
,p_attribute_08=>'TASK_OUTCOME'
,p_attribute_09=>'APPROVER'
,p_diagram=>'{"position":{"x":660,"y":1200},"z":7}'
);
wwv_flow_imp_shared.create_task_def_comp_param(
 p_id=>wwv_flow_imp.id(8750656666822713)
,p_workflow_activity_id=>wwv_flow_imp.id(8750301394822710)
,p_task_def_param_id=>wwv_flow_imp.id(8748289895833447)
,p_value_type=>'ITEM'
,p_value=>'AMOUNT'
);
wwv_flow_imp_shared.create_task_def_comp_param(
 p_id=>wwv_flow_imp.id(8750736403822714)
,p_workflow_activity_id=>wwv_flow_imp.id(8750301394822710)
,p_task_def_param_id=>wwv_flow_imp.id(8748564860833444)
,p_value_type=>'ITEM'
,p_value=>'EMP_NAME'
);
wwv_flow_imp_shared.create_task_def_comp_param(
 p_id=>wwv_flow_imp.id(8750818926822715)
,p_workflow_activity_id=>wwv_flow_imp.id(8750301394822710)
,p_task_def_param_id=>wwv_flow_imp.id(8748945113833442)
,p_value_type=>'ITEM'
,p_value=>'CURRENT_LEVEL'
);
wwv_flow_imp_shared.create_workflow_activity(
 p_id=>wwv_flow_imp.id(8750946635822716)
,p_workflow_version_id=>wwv_flow_imp.id(8221890312067346)
,p_name=>'Increment Level'
,p_static_id=>'New_5'
,p_display_sequence=>70
,p_activity_type=>'NATIVE_PLSQL'
,p_activity_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
':CURRENT_LEVEL := :CURRENT_LEVEL+1;',
'end;'))
,p_activity_code_language=>'PLSQL'
,p_location=>'LOCAL'
,p_diagram=>'{"position":{"x":1120,"y":1200},"z":8}'
);
wwv_flow_imp_shared.create_workflow_activity(
 p_id=>wwv_flow_imp.id(8751017911822717)
,p_workflow_version_id=>wwv_flow_imp.id(8221890312067346)
,p_name=>'Approved?'
,p_static_id=>'New_6'
,p_display_sequence=>80
,p_activity_type=>'NATIVE_WORKFLOW_SWITCH'
,p_attribute_01=>'TRUE_FALSE_CHECK'
,p_attribute_03=>'WF_VARIABLE_EQ_VAL'
,p_attribute_08=>'TASK_OUTCOME'
,p_attribute_14=>'APPROVED'
,p_diagram=>'{"position":{"x":660,"y":1360},"z":9}'
);
wwv_flow_imp_shared.create_workflow_activity(
 p_id=>wwv_flow_imp.id(8751181711822718)
,p_workflow_version_id=>wwv_flow_imp.id(8221890312067346)
,p_name=>'All Approvals Completed?'
,p_static_id=>'New_7'
,p_display_sequence=>90
,p_activity_type=>'NATIVE_WORKFLOW_SWITCH'
,p_attribute_01=>'CHECK_WF_VARIABLE'
,p_attribute_10=>'CURRENT_LEVEL'
,p_diagram=>'{"position":{"x":1360,"y":1360},"z":10}'
);
wwv_flow_imp_shared.create_workflow_activity(
 p_id=>wwv_flow_imp.id(8751235674822719)
,p_workflow_version_id=>wwv_flow_imp.id(8221890312067346)
,p_name=>'Rejected at First Level?'
,p_static_id=>'New_8'
,p_display_sequence=>120
,p_activity_type=>'NATIVE_WORKFLOW_SWITCH'
,p_attribute_01=>'TRUE_FALSE_CHECK'
,p_attribute_03=>'WF_VARIABLE_EQ_VAL'
,p_attribute_08=>'CURRENT_LEVEL'
,p_attribute_14=>'1'
,p_diagram=>'{"position":{"x":660,"y":1520},"z":11}'
);
wwv_flow_imp_shared.create_workflow_activity(
 p_id=>wwv_flow_imp.id(8751373579822720)
,p_workflow_version_id=>wwv_flow_imp.id(8221890312067346)
,p_name=>'Reset Level'
,p_static_id=>'New_9'
,p_display_sequence=>140
,p_activity_type=>'NATIVE_PLSQL'
,p_activity_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
':CURRENT_LEVEL := 1;',
'end;'))
,p_activity_code_language=>'PLSQL'
,p_location=>'LOCAL'
,p_diagram=>'{"position":{"x":310,"y":1520},"z":12}'
);
wwv_flow_imp_shared.create_workflow_activity(
 p_id=>wwv_flow_imp.id(8751637260822723)
,p_workflow_version_id=>wwv_flow_imp.id(8221890312067346)
,p_name=>'Send Approval Email'
,p_static_id=>'New_10'
,p_display_sequence=>100
,p_activity_type=>'NATIVE_SEND_EMAIL'
,p_attribute_01=>'&APP_EMAIL.'
,p_attribute_02=>'&EMP_EMAIL.'
,p_attribute_06=>'Reimbursement Approved'
,p_attribute_07=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Dear &EMP_NAME. ,',
'',
'Your request for reimbursement of Rs &AMOUNT. for the purpose - &DESC. has been approved.',
'Regards,',
'Expense Team'))
,p_attribute_10=>'N'
,p_diagram=>'{"position":{"x":1360,"y":1920},"z":15}'
);
wwv_flow_imp_shared.create_workflow_activity(
 p_id=>wwv_flow_imp.id(8751721970822724)
,p_workflow_version_id=>wwv_flow_imp.id(8221890312067346)
,p_name=>'Send Rejection Email'
,p_static_id=>'New_11'
,p_display_sequence=>110
,p_activity_type=>'NATIVE_SEND_EMAIL'
,p_attribute_01=>'&APP_EMAIL.'
,p_attribute_02=>'&EMP_EMAIL.'
,p_attribute_06=>'Reimbursement Rejected'
,p_attribute_07=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Dear &EMP_NAME. ,',
'',
'Your reimbursement request of Rs &AMOUNT. has been rejected by &MGR_NAME. . Please provide the necessary justification and resubmit.',
'Regards,',
'Expense Team'))
,p_attribute_10=>'N'
,p_diagram=>'{"position":{"x":660,"y":1780},"z":16}'
);
wwv_flow_imp_shared.create_workflow_activity(
 p_id=>wwv_flow_imp.id(8751801882822725)
,p_workflow_version_id=>wwv_flow_imp.id(8221890312067346)
,p_name=>'Auto Approved Email'
,p_static_id=>'New_12'
,p_display_sequence=>130
,p_activity_type=>'NATIVE_SEND_EMAIL'
,p_attribute_01=>'&APP_EMAIL.'
,p_attribute_02=>'&EMP_EMAIL.'
,p_attribute_06=>'Reimbursement Auto Approved'
,p_attribute_07=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Dear &EMP_NAME. ,',
'',
'Congratulations, your reimbursement request for amount &AMOUNT. is eligible for auto-approval!',
'Regards,',
'Expense Team'))
,p_attribute_10=>'N'
,p_diagram=>'{"position":{"x":70,"y":1780},"z":17}'
);
wwv_flow_imp_shared.create_workflow_transition(
 p_id=>wwv_flow_imp.id(8222200430067350)
,p_name=>'New'
,p_transition_type=>'NORMAL'
,p_from_activity_id=>wwv_flow_imp.id(8221923143067347)
,p_to_activity_id=>wwv_flow_imp.id(8750136408822708)
,p_diagram=>'{"source":{},"target":{"pos":{"x":180,"y":1110}},"vertices":[],"z":4,"label":{"distance":0.5,"offset":0}}'
);
wwv_flow_imp_shared.create_workflow_transition(
 p_id=>wwv_flow_imp.id(8753241167822739)
,p_name=>'New'
,p_transition_type=>'NORMAL'
,p_from_activity_id=>wwv_flow_imp.id(8750136408822708)
,p_to_activity_id=>wwv_flow_imp.id(8750229146822709)
,p_diagram=>'{"source":{},"target":{"pos":{"x":180,"y":1290}},"vertices":[],"z":24,"label":{"distance":0.5,"offset":0}}'
);
wwv_flow_imp_shared.create_workflow_transition(
 p_id=>wwv_flow_imp.id(8751488238822721)
,p_name=>'YES'
,p_transition_type=>'BRANCH'
,p_from_activity_id=>wwv_flow_imp.id(8750229146822709)
,p_to_activity_id=>wwv_flow_imp.id(8750301394822710)
,p_condition_expr1=>'FALSE'
,p_diagram=>'{"source":{},"target":{"pos":{"x":1340,"y":1250}},"vertices":[],"z":13,"label":{"distance":0.5,"offset":0}}'
);
wwv_flow_imp_shared.create_workflow_transition(
 p_id=>wwv_flow_imp.id(8751545696822722)
,p_name=>'NO'
,p_transition_type=>'BRANCH'
,p_from_activity_id=>wwv_flow_imp.id(8750229146822709)
,p_to_activity_id=>wwv_flow_imp.id(8751801882822725)
,p_condition_expr1=>'TRUE'
,p_diagram=>'{"source":{},"target":{"pos":{"x":1340,"y":1250}},"vertices":[],"z":14,"label":{"distance":0.5,"offset":0}}'
);
wwv_flow_imp_shared.create_workflow_transition(
 p_id=>wwv_flow_imp.id(8753515172822742)
,p_name=>'New'
,p_transition_type=>'NORMAL'
,p_from_activity_id=>wwv_flow_imp.id(8750301394822710)
,p_to_activity_id=>wwv_flow_imp.id(8751017911822717)
,p_diagram=>'{"source":{"name":"bottom","args":{"dx":0,"dy":-10}},"target":{"name":"topLeft","args":{"dx":"50.003%","dy":"33.34%","rotate":true}},"vertices":[],"z":26,"label":{"distance":0.5,"offset":0}}'
);
wwv_flow_imp_shared.create_workflow_transition(
 p_id=>wwv_flow_imp.id(8754080579822747)
,p_name=>'New'
,p_transition_type=>'NORMAL'
,p_from_activity_id=>wwv_flow_imp.id(8750946635822716)
,p_to_activity_id=>wwv_flow_imp.id(8750301394822710)
,p_diagram=>'{"source":{"name":"left","args":{"dx":10,"dy":0}},"target":{"name":"topLeft","args":{"dx":"95.455%","dy":"50%","rotate":true}},"vertices":[],"z":30,"label":{"distance":0.5,"offset":0}}'
);
wwv_flow_imp_shared.create_workflow_transition(
 p_id=>wwv_flow_imp.id(8751987052822726)
,p_name=>'YES'
,p_transition_type=>'BRANCH'
,p_from_activity_id=>wwv_flow_imp.id(8751017911822717)
,p_to_activity_id=>wwv_flow_imp.id(8751181711822718)
,p_condition_expr1=>'TRUE'
,p_diagram=>'{"source":{},"target":{"pos":{"x":1300,"y":1220}},"vertices":[],"z":18,"label":{"distance":0.5,"offset":0}}'
);
wwv_flow_imp_shared.create_workflow_transition(
 p_id=>wwv_flow_imp.id(8752006782822727)
,p_name=>'NO'
,p_transition_type=>'BRANCH'
,p_from_activity_id=>wwv_flow_imp.id(8751017911822717)
,p_to_activity_id=>wwv_flow_imp.id(8751235674822719)
,p_condition_expr1=>'FALSE'
,p_diagram=>'{"source":{},"target":{"pos":{"x":1300,"y":1220}},"vertices":[],"z":19,"label":{"distance":0.5,"offset":0}}'
);
wwv_flow_imp_shared.create_workflow_transition(
 p_id=>wwv_flow_imp.id(8752347991822730)
,p_name=>'NO'
,p_transition_type=>'BRANCH'
,p_from_activity_id=>wwv_flow_imp.id(8751181711822718)
,p_to_activity_id=>wwv_flow_imp.id(8750946635822716)
,p_condition_type=>'LESS_THAN'
,p_condition_expr1=>'&MAX_LEVEL.'
,p_diagram=>'{"source":{},"target":{"pos":{"x":1310,"y":1230}},"vertices":[{"x":1470,"y":1230}],"z":22,"label":{"distance":0.5,"offset":0}}'
);
wwv_flow_imp_shared.create_workflow_transition(
 p_id=>wwv_flow_imp.id(8752463453822731)
,p_name=>'YES'
,p_transition_type=>'BRANCH'
,p_from_activity_id=>wwv_flow_imp.id(8751181711822718)
,p_to_activity_id=>wwv_flow_imp.id(8751637260822723)
,p_condition_type=>'OTHERWISE'
,p_diagram=>'{"source":{},"target":{"pos":{"x":1310,"y":1230}},"vertices":[],"z":23,"label":{"distance":0.5,"offset":0}}'
);
wwv_flow_imp_shared.create_workflow_transition(
 p_id=>wwv_flow_imp.id(8752127329822728)
,p_name=>'YES'
,p_transition_type=>'BRANCH'
,p_from_activity_id=>wwv_flow_imp.id(8751235674822719)
,p_to_activity_id=>wwv_flow_imp.id(8751721970822724)
,p_condition_expr1=>'TRUE'
,p_diagram=>'{"source":{},"target":{"pos":{"x":1320,"y":1240}},"vertices":[],"z":20,"label":{"distance":0.5,"offset":0}}'
);
wwv_flow_imp_shared.create_workflow_transition(
 p_id=>wwv_flow_imp.id(8752295931822729)
,p_name=>'NO'
,p_transition_type=>'BRANCH'
,p_from_activity_id=>wwv_flow_imp.id(8751235674822719)
,p_to_activity_id=>wwv_flow_imp.id(8751373579822720)
,p_condition_expr1=>'FALSE'
,p_diagram=>'{"source":{},"target":{"pos":{"x":1320,"y":1240}},"vertices":[],"z":21,"label":{"distance":0.5,"offset":0}}'
);
wwv_flow_imp_shared.create_workflow_transition(
 p_id=>wwv_flow_imp.id(8753650233822743)
,p_name=>'New'
,p_transition_type=>'NORMAL'
,p_from_activity_id=>wwv_flow_imp.id(8751373579822720)
,p_to_activity_id=>wwv_flow_imp.id(8750301394822710)
,p_diagram=>'{"source":{"name":"top","args":{"dx":0,"dy":10}},"target":{"name":"topLeft","args":{"dx":"0%","dy":"83.333%","rotate":true}},"vertices":[{"x":420,"y":1250}],"z":27,"label":{"distance":0.5,"offset":0}}'
);
wwv_flow_imp_shared.create_workflow_transition(
 p_id=>wwv_flow_imp.id(8753796587822744)
,p_name=>'New'
,p_transition_type=>'NORMAL'
,p_from_activity_id=>wwv_flow_imp.id(8751637260822723)
,p_to_activity_id=>wwv_flow_imp.id(8222106428067349)
,p_diagram=>'{"source":{"name":"left","args":{"dx":10,"dy":0}},"target":{"name":"topLeft","args":{"dx":"83.333%","dy":"50%","rotate":true}},"vertices":[],"z":28,"label":{"distance":0.5,"offset":0}}'
);
wwv_flow_imp_shared.create_workflow_transition(
 p_id=>wwv_flow_imp.id(8753955481822746)
,p_name=>'New'
,p_transition_type=>'NORMAL'
,p_from_activity_id=>wwv_flow_imp.id(8751721970822724)
,p_to_activity_id=>wwv_flow_imp.id(8222106428067349)
,p_diagram=>'{"source":{"name":"left","args":{"dx":10,"dy":0}},"target":{"name":"topLeft","args":{"dx":"83.333%","dy":"16.667%","rotate":true}},"vertices":[{"x":430,"y":1810}],"z":29,"label":{"distance":0.5,"offset":0}}'
);
wwv_flow_imp_shared.create_workflow_transition(
 p_id=>wwv_flow_imp.id(8753384269822740)
,p_name=>'New'
,p_transition_type=>'NORMAL'
,p_from_activity_id=>wwv_flow_imp.id(8751801882822725)
,p_to_activity_id=>wwv_flow_imp.id(8222106428067349)
,p_diagram=>'{"source":{"name":"bottom","args":{"dx":0,"dy":-10}},"target":{"name":"topLeft","args":{"dx":"50%","dy":"16.667%","rotate":true}},"vertices":[],"z":25,"label":{"distance":0.5,"offset":0}}'
);
wwv_flow_imp.component_end;
end;
/
