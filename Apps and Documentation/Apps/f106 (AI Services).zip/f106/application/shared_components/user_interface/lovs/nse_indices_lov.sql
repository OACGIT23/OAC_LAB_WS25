prompt --application/shared_components/user_interface/lovs/nse_indices_lov
begin
--   Manifest
--     NSE_INDICES_LOV
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.5'
,p_default_workspace_id=>9520444236666728
,p_default_application_id=>114
,p_default_id_offset=>7872712286274028
,p_default_owner=>'INSTITUTE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(9788000950505466)
,p_lov_name=>'NSE_INDICES_LOV'
,p_source_type=>'TABLE'
,p_location=>'LOCAL'
,p_query_table=>'TRD_NSE_INDICES_MST'
,p_return_column_name=>'INDICES_ID'
,p_display_column_name=>'INDICES_NAME'
,p_group_sort_direction=>'ASC'
,p_default_sort_column_name=>'INDICES_ID'
,p_default_sort_direction=>'ASC'
,p_version_scn=>39412788140991
);
wwv_flow_imp.component_end;
end;
/
