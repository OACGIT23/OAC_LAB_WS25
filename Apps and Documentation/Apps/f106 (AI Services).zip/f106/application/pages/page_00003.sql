prompt --application/pages/page_00003
begin
--   Manifest
--     PAGE: 00003
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.5'
,p_default_workspace_id=>9520444236666728
,p_default_application_id=>114
,p_default_id_offset=>7872712286274028
,p_default_owner=>'INSTITUTE'
);
wwv_flow_imp_page.create_page(
 p_id=>3
,p_name=>'Key Value Extraction'
,p_alias=>'KEY-VALUE-EXTRACTION'
,p_step_title=>'Key Value Extraction'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'03'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(7957006936253455)
,p_name=>'Output'
,p_template=>wwv_flow_imp.id(41206219033442975)
,p_display_sequence=>30
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID,',
'       regexp_replace(FIELD_LABEL, ''([A-Z])'', '' \1'' ) FIELD_LABEL,',
'       LABEL_SCORE,',
'       case when FIELD_LABEL like ''%Date%'' then TO_CHAR(to_timestamp(FIELD_VALUE, ''YYYY-MM-DD"T"HH24:MI:SS"Z"''), ''DD-MON-YYYY'')',
'       else FIELD_VALUE',
'       end as FIELD_VALUE',
'from DOCAI_RESPONSE where FIELD_VALUE <> ''#''',
'order by ID'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P3_RESPONSE'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(41250539754442951)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(71051031401468)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>10
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(69839879401472)
,p_query_column_id=>2
,p_column_alias=>'FIELD_LABEL'
,p_column_display_sequence=>30
,p_column_heading=>'Field Label'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(70229108401471)
,p_query_column_id=>3
,p_column_alias=>'LABEL_SCORE'
,p_column_display_sequence=>60
,p_column_heading=>'Label Score'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(70686161401470)
,p_query_column_id=>4
,p_column_alias=>'FIELD_VALUE'
,p_column_display_sequence=>50
,p_column_heading=>'Field Value'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(19858994578869876)
,p_name=>'New'
,p_template=>wwv_flow_imp.id(41206219033442975)
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'        1,',
'        FIELD_TYPE_CODE,',
'        FIELD_LABEL,',
'        LABEL_SCORE,',
'        FIELD_VALUE',
'    FROM',
'            JSON_TABLE ( :P3_RESPONSE, ''$.pages[*]''',
'                COLUMNS (',
'                    PAGE_NUMBER NUMBER PATH ''$.pageNumber'',',
'                    NESTED PATH ''$.documentFields[*]''',
'                        COLUMNS (',
'                            FIELD_TYPE_CODE VARCHAR2 ( 50 ) PATH ''$.fieldType'',',
'                            FIELD_LABEL VARCHAR2 ( 100 ) PATH ''$.fieldLabel.name'',',
'                            LABEL_SCORE NUMBER PATH ''$.fieldLabel.confidence'',',
'                            FIELD_VALUE VARCHAR2 ( 1000 ) PATH ''$.fieldValue.value''',
'                        )',
'                )',
'            )',
'        JT',
'    WHERE',
'        JT.FIELD_TYPE_CODE = ''KEY_VALUE'';'))
,p_display_condition_type=>'NEVER'
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P3_RESPONSE'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(41250539754442951)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(65714843401503)
,p_query_column_id=>1
,p_column_alias=>'1'
,p_column_display_sequence=>10
,p_column_heading=>'1'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(66128556401502)
,p_query_column_id=>2
,p_column_alias=>'FIELD_TYPE_CODE'
,p_column_display_sequence=>20
,p_column_heading=>'Field Type Code'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(66491172401496)
,p_query_column_id=>3
,p_column_alias=>'FIELD_LABEL'
,p_column_display_sequence=>30
,p_column_heading=>'Field Label'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(66973829401495)
,p_query_column_id=>4
,p_column_alias=>'LABEL_SCORE'
,p_column_display_sequence=>40
,p_column_heading=>'Label Score'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(67330454401493)
,p_query_column_id=>5
,p_column_alias=>'FIELD_VALUE'
,p_column_display_sequence=>50
,p_column_heading=>'Field Value'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(61907686736502003)
,p_plug_name=>'Key Value Extraction'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(41206219033442975)
,p_plug_display_sequence=>10
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(68141132401484)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(61907686736502003)
,p_button_name=>'SUBMIT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(41297136384442916)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Submit'
,p_grid_new_row=>'Y'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8058283103488034)
,p_name=>'P3_FILENAME'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(61907686736502003)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(61913432544501924)
,p_name=>'P3_UPLOAD_FILE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(61907686736502003)
,p_prompt=>'Upload File'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(41294675418442921)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'allow_multiple_files', 'N',
  'display_as', 'DROPZONE_BLOCK',
  'purge_file_at', 'SESSION',
  'storage_type', 'APEX_APPLICATION_TEMP_FILES')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(61914378819501933)
,p_name=>'P3_RESPONSE'
,p_data_type=>'CLOB'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(61907686736502003)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(71627886401458)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Get Filename'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    select filename',
'    into :P3_FILENAME',
'    from apex_application_temp_files ',
'    where name = :P3_UPLOAD_FILE;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>7944340172675486
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(72031469401456)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_EXECUTION_CHAIN'
,p_process_name=>'Process Execution Chain'
,p_attribute_01=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>7944743755675484
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(72459741401454)
,p_process_sequence=>20
,p_parent_process_id=>wwv_flow_imp.id(72031469401456)
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'Upload File to Object Storage'
,p_attribute_01=>'PLSQL_PROCEDURE_FUNCTION'
,p_attribute_05=>'UPLOAD_FILE'
,p_process_when_button_id=>wwv_flow_imp.id(68141132401484)
,p_internal_uid=>7945172027675482
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(72957609401451)
,p_page_process_id=>wwv_flow_imp.id(72459741401454)
,p_page_id=>3
,p_name=>'p_file_content'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>10
,p_value_type=>'ITEM'
,p_value=>'P3_UPLOAD_FILE'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(73400003401449)
,p_page_process_id=>wwv_flow_imp.id(72459741401454)
,p_page_id=>3
,p_name=>'p_static_id'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>20
,p_value_type=>'STATIC'
,p_value=>'oci_document_reading_credentials'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(73981552401448)
,p_page_process_id=>wwv_flow_imp.id(72459741401454)
,p_page_id=>3
,p_name=>'p_namespace'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>30
,p_value_type=>'STATIC'
,p_value=>'bmnh6evlwogt'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(74431824401446)
,p_page_process_id=>wwv_flow_imp.id(72459741401454)
,p_page_id=>3
,p_name=>'p_bucket'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>40
,p_value_type=>'STATIC'
,p_value=>'bucket-20250701-1528'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(74973866401444)
,p_page_process_id=>wwv_flow_imp.id(72459741401454)
,p_page_id=>3
,p_name=>'p_region'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>50
,p_value_type=>'STATIC'
,p_value=>'ap-mumbai-1'
,p_param_comment=>'ap-mumbai-1'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(75483180401443)
,p_page_process_id=>wwv_flow_imp.id(72459741401454)
,p_page_id=>3
,p_name=>'p_object_storage_url'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>true
,p_display_sequence=>60
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(75903602401441)
,p_page_process_id=>wwv_flow_imp.id(72459741401454)
,p_page_id=>3
,p_name=>'p_file_name'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>true
,p_display_sequence=>70
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(76422602401439)
,p_page_process_id=>wwv_flow_imp.id(72459741401454)
,p_page_id=>3
,p_name=>'p_mime_type'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>true
,p_display_sequence=>80
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(76876343401438)
,p_process_sequence=>30
,p_parent_process_id=>wwv_flow_imp.id(72031469401456)
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'Integrate Document Reading API'
,p_location=>'WEB_SOURCE'
,p_web_src_module_id=>wwv_flow_imp.id(12036020381606854)
,p_web_src_operation_id=>wwv_flow_imp.id(12037448854606846)
,p_attribute_01=>'WEB_SOURCE'
,p_process_when_button_id=>wwv_flow_imp.id(68141132401484)
,p_internal_uid=>7949588629675466
);
wwv_flow_imp_shared.create_web_source_comp_param(
 p_id=>wwv_flow_imp.id(77302170401435)
,p_page_id=>3
,p_web_src_param_id=>wwv_flow_imp.id(12037805801606845)
,p_page_process_id=>wwv_flow_imp.id(76876343401438)
,p_value_type=>'STATIC'
,p_value=>'bucket-20250701-1528'
);
wwv_flow_imp_shared.create_web_source_comp_param(
 p_id=>wwv_flow_imp.id(77831419401434)
,p_page_id=>3
,p_web_src_param_id=>wwv_flow_imp.id(12038385017606844)
,p_page_process_id=>wwv_flow_imp.id(76876343401438)
,p_value_type=>'STATIC'
,p_value=>'ocid1.tenancy.oc1..aaaaaaaauhvadux7mua2yzkvnferohlvvdnhcn6hhz3xi5vh3nvizrjnlala'
);
wwv_flow_imp_shared.create_web_source_comp_param(
 p_id=>wwv_flow_imp.id(78294569401432)
,p_page_id=>3
,p_web_src_param_id=>wwv_flow_imp.id(12039306827606844)
,p_page_process_id=>wwv_flow_imp.id(76876343401438)
,p_value_type=>'STATIC'
,p_value=>'KEY_VALUE_EXTRACTION'
);
wwv_flow_imp_shared.create_web_source_comp_param(
 p_id=>wwv_flow_imp.id(78849825401430)
,p_page_id=>3
,p_web_src_param_id=>wwv_flow_imp.id(12039804551606843)
,p_page_process_id=>wwv_flow_imp.id(76876343401438)
,p_value_type=>'STATIC'
,p_value=>'bmnh6evlwogt'
);
wwv_flow_imp_shared.create_web_source_comp_param(
 p_id=>wwv_flow_imp.id(79329934401428)
,p_page_id=>3
,p_web_src_param_id=>wwv_flow_imp.id(12040376343606843)
,p_page_process_id=>wwv_flow_imp.id(76876343401438)
,p_value_type=>'ITEM'
,p_value=>'P3_FILENAME'
);
wwv_flow_imp_shared.create_web_source_comp_param(
 p_id=>wwv_flow_imp.id(79835461401426)
,p_page_id=>3
,p_web_src_param_id=>wwv_flow_imp.id(12040827327606843)
,p_page_process_id=>wwv_flow_imp.id(76876343401438)
,p_value_type=>'ITEM'
,p_value=>'P3_RESPONSE'
,p_ignore_output=>false
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(80276446401425)
,p_process_sequence=>40
,p_parent_process_id=>wwv_flow_imp.id(72031469401456)
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Parse Response'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'',
'DELETE FROM DOCAI_RESPONSE;',
'',
'INSERT INTO DOCAI_RESPONSE(',
'    FIELD_TYPE_CODE,',
'    FIELD_LABEL,',
'    LABEL_SCORE,',
'    FIELD_VALUE',
')',
'    SELECT',
'        FIELD_TYPE_CODE,',
'        FIELD_LABEL,',
'        LABEL_SCORE,',
'        FIELD_VALUE',
'    FROM',
'            JSON_TABLE ( :P3_RESPONSE, ''$.pages[*]''',
'                COLUMNS (',
'                    PAGE_NUMBER NUMBER PATH ''$.pageNumber'',',
'                    NESTED PATH ''$.documentFields[*]''',
'                        COLUMNS (',
'                            FIELD_TYPE_CODE VARCHAR2 ( 50 ) PATH ''$.fieldType'',',
'                            FIELD_LABEL VARCHAR2 ( 100 ) PATH ''$.fieldLabel.name'',',
'                            LABEL_SCORE NUMBER PATH ''$.fieldLabel.confidence'',',
'                            FIELD_VALUE VARCHAR2 ( 1000 ) PATH ''$.fieldValue.value''',
'                        )',
'                )',
'            )',
'        JT',
'    WHERE',
'        JT.FIELD_TYPE_CODE = ''KEY_VALUE'';',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_process_when_button_id=>wwv_flow_imp.id(68141132401484)
,p_process_success_message=>'Processed'
,p_internal_uid=>7952988732675453
);
wwv_flow_imp.component_end;
end;
/
