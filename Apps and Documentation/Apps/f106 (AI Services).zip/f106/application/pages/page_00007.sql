prompt --application/pages/page_00007
begin
--   Manifest
--     PAGE: 00007
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.5'
,p_default_workspace_id=>9520444236666728
,p_default_application_id=>114
,p_default_id_offset=>7872712286274028
,p_default_owner=>'INSTITUTE'
);
wwv_flow_imp_page.create_page(
 p_id=>7
,p_name=>'Object Detection'
,p_alias=>'OBJECT-DETECTION1'
,p_step_title=>'Object Detection'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'03'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(23964162636841480)
,p_name=>'Output'
,p_template=>wwv_flow_imp.id(41206219033442975)
,p_display_sequence=>30
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT jt.name,',
'       (jt.confidence * 100) || ''%'' AS PERCENTAGE',
'FROM JSON_TABLE(',
'       :P7_RESPONSE, ',
'       ''$.imageObjects[*]'' ',
'       COLUMNS (',
'         name       VARCHAR2(100) PATH ''$.name'',',
'         confidence NUMBER        PATH ''$.confidence''',
'       )',
'     ) jt;'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P7_RESPONSE'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(41250539754442951)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(154028270819130)
,p_query_column_id=>1
,p_column_alias=>'NAME'
,p_column_display_sequence=>10
,p_column_heading=>'Name'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(131641576204293)
,p_query_column_id=>2
,p_column_alias=>'PERCENTAGE'
,p_column_display_sequence=>20
,p_column_heading=>'Percentage'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(77914842437090028)
,p_plug_name=>'Object Detection'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(41206219033442975)
,p_plug_display_sequence=>10
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(151910261819141)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(77914842437090028)
,p_button_name=>'SUBMIT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(41297136384442916)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Submit'
,p_grid_new_row=>'Y'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(24070657910076008)
,p_name=>'P7_FILENAME'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(77914842437090028)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(77925807351089898)
,p_name=>'P7_UPLOAD_FILE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(77914842437090028)
,p_prompt=>'Upload File'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(41294675418442921)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'allow_multiple_files', 'N',
  'display_as', 'DROPZONE_BLOCK',
  'purge_file_at', 'SESSION',
  'storage_type', 'APEX_APPLICATION_TEMP_FILES')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(77926753626089907)
,p_name=>'P7_RESPONSE'
,p_data_type=>'CLOB'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(77914842437090028)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(154636302819128)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Get Filename'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    select filename',
'    into :P7_FILENAME',
'    from apex_application_temp_files ',
'    where name = :P7_UPLOAD_FILE;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>8027348589093156
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(155040321819124)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_EXECUTION_CHAIN'
,p_process_name=>'Process Execution Chain'
,p_attribute_01=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>8027752608093152
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(155452258819123)
,p_process_sequence=>20
,p_parent_process_id=>wwv_flow_imp.id(155040321819124)
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'Upload File to Object Storage'
,p_attribute_01=>'PLSQL_PROCEDURE_FUNCTION'
,p_attribute_05=>'UPLOAD_FILE'
,p_process_when_button_id=>wwv_flow_imp.id(151910261819141)
,p_internal_uid=>8028164545093151
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(155981860819121)
,p_page_process_id=>wwv_flow_imp.id(155452258819123)
,p_page_id=>7
,p_name=>'p_file_content'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>10
,p_value_type=>'ITEM'
,p_value=>'P7_UPLOAD_FILE'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(156403616819120)
,p_page_process_id=>wwv_flow_imp.id(155452258819123)
,p_page_id=>7
,p_name=>'p_static_id'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>20
,p_value_type=>'STATIC'
,p_value=>'oci_document_reading_credentials'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(156888871819118)
,p_page_process_id=>wwv_flow_imp.id(155452258819123)
,p_page_id=>7
,p_name=>'p_namespace'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>30
,p_value_type=>'STATIC'
,p_value=>'bmnh6evlwogt'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(157479656819117)
,p_page_process_id=>wwv_flow_imp.id(155452258819123)
,p_page_id=>7
,p_name=>'p_bucket'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>40
,p_value_type=>'STATIC'
,p_value=>'bucket-20250701-1528'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(157946794819115)
,p_page_process_id=>wwv_flow_imp.id(155452258819123)
,p_page_id=>7
,p_name=>'p_region'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>50
,p_value_type=>'STATIC'
,p_value=>'ap-mumbai-1'
,p_param_comment=>'ap-mumbai-1'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(158357750819114)
,p_page_process_id=>wwv_flow_imp.id(155452258819123)
,p_page_id=>7
,p_name=>'p_object_storage_url'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>true
,p_display_sequence=>60
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(158887391819112)
,p_page_process_id=>wwv_flow_imp.id(155452258819123)
,p_page_id=>7
,p_name=>'p_file_name'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>true
,p_display_sequence=>70
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(159341990819111)
,p_page_process_id=>wwv_flow_imp.id(155452258819123)
,p_page_id=>7
,p_name=>'p_mime_type'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>true
,p_display_sequence=>80
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(159739396819110)
,p_process_sequence=>30
,p_parent_process_id=>wwv_flow_imp.id(155040321819124)
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'Integrate Document Reading API'
,p_location=>'WEB_SOURCE'
,p_web_src_module_id=>wwv_flow_imp.id(64586114678602)
,p_web_src_operation_id=>wwv_flow_imp.id(66006455678601)
,p_attribute_01=>'WEB_SOURCE'
,p_process_when_button_id=>wwv_flow_imp.id(151910261819141)
,p_internal_uid=>8032451683093138
);
wwv_flow_imp_shared.create_web_source_comp_param(
 p_id=>wwv_flow_imp.id(160239987819108)
,p_page_id=>7
,p_web_src_param_id=>wwv_flow_imp.id(90494230584547)
,p_page_process_id=>wwv_flow_imp.id(159739396819110)
,p_value_type=>'STATIC'
,p_value=>'bucket-20250701-1528'
);
wwv_flow_imp_shared.create_web_source_comp_param(
 p_id=>wwv_flow_imp.id(160717828819107)
,p_page_id=>7
,p_web_src_param_id=>wwv_flow_imp.id(66866084678601)
,p_page_process_id=>wwv_flow_imp.id(159739396819110)
,p_value_type=>'STATIC'
,p_value=>'ocid1.tenancy.oc1..aaaaaaaauhvadux7mua2yzkvnferohlvvdnhcn6hhz3xi5vh3nvizrjnlala'
);
wwv_flow_imp_shared.create_web_source_comp_param(
 p_id=>wwv_flow_imp.id(161205434819105)
,p_page_id=>7
,p_web_src_param_id=>wwv_flow_imp.id(67834057678600)
,p_page_process_id=>wwv_flow_imp.id(159739396819110)
,p_value_type=>'STATIC'
,p_value=>'OBJECT_DETECTION'
);
wwv_flow_imp_shared.create_web_source_comp_param(
 p_id=>wwv_flow_imp.id(161743531819104)
,p_page_id=>7
,p_web_src_param_id=>wwv_flow_imp.id(90015896584547)
,p_page_process_id=>wwv_flow_imp.id(159739396819110)
,p_value_type=>'STATIC'
,p_value=>'bmnh6evlwogt'
);
wwv_flow_imp_shared.create_web_source_comp_param(
 p_id=>wwv_flow_imp.id(162226233819102)
,p_page_id=>7
,p_web_src_param_id=>wwv_flow_imp.id(90973845584547)
,p_page_process_id=>wwv_flow_imp.id(159739396819110)
,p_value_type=>'ITEM'
,p_value=>'P7_FILENAME'
);
wwv_flow_imp_shared.create_web_source_comp_param(
 p_id=>wwv_flow_imp.id(162751822819100)
,p_page_id=>7
,p_web_src_param_id=>wwv_flow_imp.id(69386575678600)
,p_page_process_id=>wwv_flow_imp.id(159739396819110)
,p_value_type=>'ITEM'
,p_value=>'P7_RESPONSE'
,p_ignore_output=>false
);
wwv_flow_imp.component_end;
end;
/
