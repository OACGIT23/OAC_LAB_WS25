prompt --application/shared_components/web_sources/oci_document_reader
begin
--   Manifest
--     WEB SOURCE: OCI Document Reader
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.6'
,p_default_workspace_id=>9520444236666728
,p_default_application_id=>114
,p_default_id_offset=>7872712286274028
,p_default_owner=>'INSTITUTE'
);
wwv_flow_imp_shared.create_web_source_module(
 p_id=>wwv_flow_imp.id(41938466171043320)
,p_name=>'OCI Document Reader'
,p_static_id=>'oci_document_reader'
,p_web_source_type=>'NATIVE_OCI'
,p_data_profile_id=>wwv_flow_imp.id(41937387645043321)
,p_remote_server_id=>wwv_flow_imp.id(28939645522510091)
,p_url_path_prefix=>'/analyzeDocument'
,p_credential_id=>wwv_flow_imp.id(316086884359)
,p_version_scn=>44956741517249
);
wwv_flow_imp_shared.create_web_source_operation(
 p_id=>wwv_flow_imp.id(41938644697043320)
,p_web_src_module_id=>wwv_flow_imp.id(41938466171043320)
,p_operation=>'GET'
,p_database_operation=>'FETCH_COLLECTION'
,p_url_pattern=>'.'
,p_force_error_for_http_404=>false
,p_allow_fetch_all_rows=>false
);
wwv_flow_imp_shared.create_web_source_operation(
 p_id=>wwv_flow_imp.id(41939029271043320)
,p_web_src_module_id=>wwv_flow_imp.id(41938466171043320)
,p_operation=>'POST'
,p_url_pattern=>'.'
,p_request_body_template=>wwv_flow_string.join(wwv_flow_t_varchar2(
'{',
'  "compartmentId": "#COMPARTMENT_ID#",',
'  "document": {',
'    "namespaceName": "#NAMESPACE_NAME#",',
'    "bucketName": "#BUCKET_NAME#",',
'    "objectName": "#OBJECT_NAME#",',
'    "source": "OBJECT_STORAGE"',
'  },',
'  "features": [',
'    {',
'      "featureType": "#FEATURE_TYPE#"',
'    }',
'  ]',
'}'))
,p_force_error_for_http_404=>false
,p_allow_fetch_all_rows=>false
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(41940485065028824)
,p_web_src_module_id=>wwv_flow_imp.id(41938466171043320)
,p_web_src_operation_id=>wwv_flow_imp.id(41939029271043320)
,p_name=>'COMPARTMENT_ID'
,p_param_type=>'BODY'
,p_data_type=>'VARCHAR2'
,p_is_required=>false
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(41940976751028824)
,p_web_src_module_id=>wwv_flow_imp.id(41938466171043320)
,p_web_src_operation_id=>wwv_flow_imp.id(41939029271043320)
,p_name=>'NAMESPACE_NAME'
,p_param_type=>'BODY'
,p_data_type=>'VARCHAR2'
,p_is_required=>false
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(41941400807028824)
,p_web_src_module_id=>wwv_flow_imp.id(41938466171043320)
,p_web_src_operation_id=>wwv_flow_imp.id(41939029271043320)
,p_name=>'BUCKET_NAME'
,p_param_type=>'BODY'
,p_data_type=>'VARCHAR2'
,p_is_required=>false
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(41941911698028824)
,p_web_src_module_id=>wwv_flow_imp.id(41938466171043320)
,p_web_src_operation_id=>wwv_flow_imp.id(41939029271043320)
,p_name=>'OBJECT_NAME'
,p_param_type=>'BODY'
,p_data_type=>'VARCHAR2'
,p_is_required=>false
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(41942401049028823)
,p_web_src_module_id=>wwv_flow_imp.id(41938466171043320)
,p_web_src_operation_id=>wwv_flow_imp.id(41939029271043320)
,p_name=>'FEATURE_TYPE'
,p_param_type=>'BODY'
,p_data_type=>'VARCHAR2'
,p_is_required=>false
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(41942945145022064)
,p_web_src_module_id=>wwv_flow_imp.id(41938466171043320)
,p_web_src_operation_id=>wwv_flow_imp.id(41939029271043320)
,p_name=>'RESPONSE'
,p_param_type=>'BODY'
,p_is_required=>false
,p_direction=>'OUT'
);
wwv_flow_imp_shared.create_web_source_param(
 p_id=>wwv_flow_imp.id(41943318842018045)
,p_web_src_module_id=>wwv_flow_imp.id(41938466171043320)
,p_web_src_operation_id=>wwv_flow_imp.id(41939029271043320)
,p_name=>'Content-Type'
,p_param_type=>'HEADER'
,p_data_type=>'VARCHAR2'
,p_is_required=>false
,p_value=>'application/json'
,p_is_static=>true
);
wwv_flow_imp_shared.create_web_source_operation(
 p_id=>wwv_flow_imp.id(41939460121043319)
,p_web_src_module_id=>wwv_flow_imp.id(41938466171043320)
,p_operation=>'PUT'
,p_database_operation=>'UPDATE'
,p_url_pattern=>'/:id'
,p_allow_fetch_all_rows=>false
);
wwv_flow_imp_shared.create_web_source_operation(
 p_id=>wwv_flow_imp.id(41939849058043319)
,p_web_src_module_id=>wwv_flow_imp.id(41938466171043320)
,p_operation=>'DELETE'
,p_database_operation=>'DELETE'
,p_url_pattern=>'/:id'
,p_allow_fetch_all_rows=>false
);
wwv_flow_imp.component_end;
end;
/
