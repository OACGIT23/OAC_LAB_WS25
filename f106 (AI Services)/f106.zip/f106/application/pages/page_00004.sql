prompt --application/pages/page_00004
begin
--   Manifest
--     PAGE: 00004
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.6'
,p_default_workspace_id=>9520444236666728
,p_default_application_id=>114
,p_default_id_offset=>7872712286274028
,p_default_owner=>'INSTITUTE'
);
wwv_flow_imp_page.create_page(
 p_id=>4
,p_name=>'Table  Extraction'
,p_alias=>'TABLE-EXTRACTION1'
,p_step_title=>'Table  Extraction'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'03'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(132484625204301)
,p_name=>'Output'
,p_template=>wwv_flow_imp.id(41206219033442975)
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT jh.h_cell_text,',
'    jb.b_cell_text',
'FROM ',
'    JSON_TABLE(',
'		:P4_RESPONSE,''$.pages[0].tables[0].headerRows[0].cells[*]''',
'		COLUMNS (',
'			h_cell_text VARCHAR2(4000) PATH ''$.text'',',
'			h_col_index NUMBER PATH ''$.columnIndex''',
'		)',
'	) jh,',
'    JSON_TABLE(',
'		:P4_RESPONSE, ''$.pages[0].tables[0].bodyRows[*].cells[*]''',
'		COLUMNS (',
'			b_cell_text VARCHAR2(4000) PATH ''$.text'',',
'			b_col_index NUMBER PATH ''$.columnIndex''',
'		)',
'    ) jb',
'WHERE jh.h_col_index = jb.b_col_index',
'ORDER BY jh.h_col_index'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P4_RESPONSE'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(41250539754442951)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(134366999204320)
,p_query_column_id=>1
,p_column_alias=>'H_CELL_TEXT'
,p_column_display_sequence=>10
,p_column_heading=>'Columns'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(134462555204321)
,p_query_column_id=>2
,p_column_alias=>'B_CELL_TEXT'
,p_column_display_sequence=>20
,p_column_heading=>'Rows'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(61924758805497709)
,p_plug_name=>'Table  Extraction'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(41206219033442975)
,p_plug_display_sequence=>10
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(85225239397209)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(61924758805497709)
,p_button_name=>'SUBMIT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(41297136384442916)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Submit'
,p_grid_new_row=>'Y'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8075402813483760)
,p_name=>'P4_FILENAME'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(61924758805497709)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(61930552254497650)
,p_name=>'P4_UPLOAD_FILE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(61924758805497709)
,p_prompt=>'Upload File'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(41294675418442921)
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'allow_multiple_files', 'N',
  'display_as', 'DROPZONE_BLOCK',
  'purge_file_at', 'SESSION',
  'storage_type', 'APEX_APPLICATION_TEMP_FILES')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(61931498529497659)
,p_name=>'P4_RESPONSE'
,p_data_type=>'CLOB'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(61924758805497709)
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(88692387397195)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Get Filename'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    select filename',
'    into :P4_FILENAME',
'    from apex_application_temp_files ',
'    where name = :P4_UPLOAD_FILE;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>7961404673671223
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(89093575397194)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_EXECUTION_CHAIN'
,p_process_name=>'Process Execution Chain'
,p_attribute_01=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>7961805861671222
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1173342064363395)
,p_process_sequence=>10
,p_parent_process_id=>wwv_flow_imp.id(89093575397194)
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'Upload File to Object Storage'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'AI_SERVICES_PKG'
,p_attribute_04=>'UPLOAD_FILE_TO_OBJECT_STORAGE'
,p_process_when_button_id=>wwv_flow_imp.id(85225239397209)
,p_internal_uid=>9046054350637423
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(1173731708363392)
,p_page_process_id=>wwv_flow_imp.id(1173342064363395)
,p_page_id=>4
,p_name=>'p_file_content'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>10
,p_value_type=>'ITEM'
,p_value=>'P4_UPLOAD_FILE'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(1174278725363390)
,p_page_process_id=>wwv_flow_imp.id(1173342064363395)
,p_page_id=>4
,p_name=>'p_static_id'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>20
,p_value_type=>'STATIC'
,p_value=>'oci_document_reading_credentials'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(1174767667363388)
,p_page_process_id=>wwv_flow_imp.id(1173342064363395)
,p_page_id=>4
,p_name=>'p_namespace'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>30
,p_value_type=>'STATIC'
,p_value=>'bmnh6evlwogt'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(1175242324363387)
,p_page_process_id=>wwv_flow_imp.id(1173342064363395)
,p_page_id=>4
,p_name=>'p_bucket'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>40
,p_value_type=>'STATIC'
,p_value=>'bucket-20250701-1528'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(1175732538363385)
,p_page_process_id=>wwv_flow_imp.id(1173342064363395)
,p_page_id=>4
,p_name=>'p_region'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>50
,p_value_type=>'STATIC'
,p_value=>'ap-mumbai-1'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(1176190872363382)
,p_page_process_id=>wwv_flow_imp.id(1173342064363395)
,p_page_id=>4
,p_name=>'p_object_storage_url'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>true
,p_display_sequence=>60
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(1176743567363380)
,p_page_process_id=>wwv_flow_imp.id(1173342064363395)
,p_page_id=>4
,p_name=>'p_file_name'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>true
,p_display_sequence=>70
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(1177221501363378)
,p_page_process_id=>wwv_flow_imp.id(1173342064363395)
,p_page_id=>4
,p_name=>'p_mime_type'
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>true
,p_display_sequence=>80
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(93986665397179)
,p_process_sequence=>30
,p_parent_process_id=>wwv_flow_imp.id(89093575397194)
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'Integrate Document Reading API'
,p_location=>'WEB_SOURCE'
,p_web_src_module_id=>wwv_flow_imp.id(12036020381606854)
,p_web_src_operation_id=>wwv_flow_imp.id(12037448854606846)
,p_attribute_01=>'WEB_SOURCE'
,p_process_when_button_id=>wwv_flow_imp.id(85225239397209)
,p_internal_uid=>7966698951671207
);
wwv_flow_imp_shared.create_web_source_comp_param(
 p_id=>wwv_flow_imp.id(94437130397177)
,p_page_id=>4
,p_web_src_param_id=>wwv_flow_imp.id(12037805801606845)
,p_page_process_id=>wwv_flow_imp.id(93986665397179)
,p_value_type=>'STATIC'
,p_value=>'bucket-20250701-1528'
);
wwv_flow_imp_shared.create_web_source_comp_param(
 p_id=>wwv_flow_imp.id(94901577397175)
,p_page_id=>4
,p_web_src_param_id=>wwv_flow_imp.id(12038385017606844)
,p_page_process_id=>wwv_flow_imp.id(93986665397179)
,p_value_type=>'STATIC'
,p_value=>'ocid1.tenancy.oc1..aaaaaaaauhvadux7mua2yzkvnferohlvvdnhcn6hhz3xi5vh3nvizrjnlala'
);
wwv_flow_imp_shared.create_web_source_comp_param(
 p_id=>wwv_flow_imp.id(95429346397172)
,p_page_id=>4
,p_web_src_param_id=>wwv_flow_imp.id(12039306827606844)
,p_page_process_id=>wwv_flow_imp.id(93986665397179)
,p_value_type=>'STATIC'
,p_value=>'TABLE_EXTRACTION'
);
wwv_flow_imp_shared.create_web_source_comp_param(
 p_id=>wwv_flow_imp.id(95915920397170)
,p_page_id=>4
,p_web_src_param_id=>wwv_flow_imp.id(12039804551606843)
,p_page_process_id=>wwv_flow_imp.id(93986665397179)
,p_value_type=>'STATIC'
,p_value=>'bmnh6evlwogt'
);
wwv_flow_imp_shared.create_web_source_comp_param(
 p_id=>wwv_flow_imp.id(96398980397169)
,p_page_id=>4
,p_web_src_param_id=>wwv_flow_imp.id(12040376343606843)
,p_page_process_id=>wwv_flow_imp.id(93986665397179)
,p_value_type=>'ITEM'
,p_value=>'P4_FILENAME'
);
wwv_flow_imp_shared.create_web_source_comp_param(
 p_id=>wwv_flow_imp.id(96890031397167)
,p_page_id=>4
,p_web_src_param_id=>wwv_flow_imp.id(12040827327606843)
,p_page_process_id=>wwv_flow_imp.id(93986665397179)
,p_value_type=>'ITEM'
,p_value=>'P4_RESPONSE'
,p_ignore_output=>false
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(97291750397166)
,p_process_sequence=>40
,p_parent_process_id=>wwv_flow_imp.id(89093575397194)
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Parse Response'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    DELETE FROM AI_TABLE_EXTRACT;',
'    ',
'    INSERT INTO AI_TABLE_EXTRACT (source, json_data)',
'    VALUES (''DocumentAI Form'', :P4_RESPONSE);',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_process_when_button_id=>wwv_flow_imp.id(85225239397209)
,p_process_success_message=>'Processed'
,p_internal_uid=>7970004036671194
);
wwv_flow_imp.component_end;
end;
/
