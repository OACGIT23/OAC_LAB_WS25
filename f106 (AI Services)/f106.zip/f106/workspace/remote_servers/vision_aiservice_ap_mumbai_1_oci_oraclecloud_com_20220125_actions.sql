prompt --workspace/remote_servers/vision_aiservice_ap_mumbai_1_oci_oraclecloud_com_20220125_actions
begin
--   Manifest
--     REMOTE SERVER: vision-aiservice-ap-mumbai-1-oci-oraclecloud-com-20220125-actions
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.6'
,p_default_workspace_id=>9520444236666728
,p_default_application_id=>114
,p_default_id_offset=>7872712286274028
,p_default_owner=>'INSTITUTE'
);
wwv_imp_workspace.create_remote_server(
 p_id=>wwv_flow_imp.id(28921953668740251)
,p_name=>'vision-aiservice-ap-mumbai-1-oci-oraclecloud-com-20220125-actions'
,p_static_id=>'vision_aiservice_ap_mumbai_1_oci_oraclecloud_com_20220125_actions'
,p_base_url=>nvl(wwv_flow_application_install.get_remote_server_base_url('vision_aiservice_ap_mumbai_1_oci_oraclecloud_com_20220125_actions'),'https://vision.aiservice.ap-mumbai-1.oci.oraclecloud.com/20220125/actions/')
,p_https_host=>nvl(wwv_flow_application_install.get_remote_server_https_host('vision_aiservice_ap_mumbai_1_oci_oraclecloud_com_20220125_actions'),'')
,p_server_type=>'WEB_SERVICE'
,p_ords_timezone=>nvl(wwv_flow_application_install.get_remote_server_ords_tz('vision_aiservice_ap_mumbai_1_oci_oraclecloud_com_20220125_actions'),'')
,p_remote_sql_default_schema=>nvl(wwv_flow_application_install.get_remote_server_default_db('vision_aiservice_ap_mumbai_1_oci_oraclecloud_com_20220125_actions'),'')
,p_mysql_sql_modes=>nvl(wwv_flow_application_install.get_remote_server_sql_mode('vision_aiservice_ap_mumbai_1_oci_oraclecloud_com_20220125_actions'),'')
,p_prompt_on_install=>false
,p_ai_is_builder_service=>false
,p_ai_model_name=>nvl(wwv_flow_application_install.get_remote_server_ai_model('vision_aiservice_ap_mumbai_1_oci_oraclecloud_com_20220125_actions'),'')
,p_ai_http_headers=>nvl(wwv_flow_application_install.get_remote_server_ai_headers('vision_aiservice_ap_mumbai_1_oci_oraclecloud_com_20220125_actions'),'')
,p_ai_attributes=>nvl(wwv_flow_application_install.get_remote_server_ai_attrs('vision_aiservice_ap_mumbai_1_oci_oraclecloud_com_20220125_actions'),'')
);
wwv_flow_imp.component_end;
end;
/
