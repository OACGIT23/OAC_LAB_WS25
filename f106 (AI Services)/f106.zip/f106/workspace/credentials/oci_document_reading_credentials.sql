prompt --workspace/credentials/oci_document_reading_credentials
begin
--   Manifest
--     CREDENTIAL: OCI Document Reading Credentials
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.6'
,p_default_workspace_id=>9520444236666728
,p_default_application_id=>114
,p_default_id_offset=>7872712286274028
,p_default_owner=>'INSTITUTE'
);
wwv_imp_workspace.create_credential(
 p_id=>wwv_flow_imp.id(316086884359)
,p_name=>'OCI Document Reading Credentials'
,p_static_id=>'oci_document_reading_credentials'
,p_authentication_type=>'OCI'
,p_namespace=>'ocid1.tenancy.oc1..aaaaaaaauhvadux7mua2yzkvnferohlvvdnhcn6hhz3xi5vh3nvizrjnlala'
,p_prompt_on_install=>false
);
wwv_flow_imp.component_end;
end;
/
