prompt --application/shared_components/navigation/search_config/milestones_vector
begin
--   Manifest
--     SEARCH CONFIG: Milestones - Vector
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.6'
,p_default_workspace_id=>7834776098045050
,p_default_application_id=>107
,p_default_id_offset=>0
,p_default_owner=>'WKSP_OACLABWS'
);
wwv_flow_imp_shared.create_search_config(
 p_id=>wwv_flow_imp.id(8096415230029616)
,p_label=>'Milestones - Vector'
,p_static_id=>'milestones_vector'
,p_search_type=>'VECTOR'
,p_location=>'LOCAL'
,p_query_type=>'TABLE'
,p_query_table=>'EBA_PROJECT_MILESTONES'
,p_oratext_index_column_name=>'VECTOR_COLUMN'
,p_vector_provider_id =>wwv_flow_imp.id(8069625545089502)
,p_vector_search_type=>'EXACT'
,p_vector_distance_metric=>'COSINE'
,p_return_max_results=>100
,p_pk_column_name=>'ID'
,p_title_column_name=>'NAME'
,p_description_column_name=>'DESCRIPTION'
,p_custom_01_column_name=>'DUE_DATE'
,p_icon_source_type=>'INITIALS'
,p_version_scn=>44957096477385
);
wwv_flow_imp.component_end;
end;
/
